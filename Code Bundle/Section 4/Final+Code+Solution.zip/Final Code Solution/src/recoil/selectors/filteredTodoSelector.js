import { todoListAtom } from "../atoms/todoAtom";
import { selector } from "recoil";
import { filterOptionAtom } from "../atoms/filterOptionAtom";

// get the filter option atom and pass it into our selector function
// and return conditionally the todoList or the filtered version accordingly

export const filteredTodoListSelector = selector({
  key: "filteredTodoListSelector",
  get: ({ get }) => {
    const todoList = get(todoListAtom);
    const filterOption = get(filterOptionAtom);

    if (filterOption === "all") {
      return todoList;
    } else if (filterOption === "completed") {
      return todoList.filter((item) => item.isComplete);
    }
    return [];
  },
});
