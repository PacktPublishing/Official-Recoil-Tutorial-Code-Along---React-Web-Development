import {atom} from 'recoil';

export const filterOptionAtom = atom({
    key: 'filterOptionAtom',
    default:'all'
});

